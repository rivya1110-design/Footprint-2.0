document.addEventListener("DOMContentLoaded", () => {
  "use strict";

  const officialInput = document.getElementById("officialUsername");
  const suspiciousInput = document.getElementById("suspiciousUsername");
  const platformInput = document.getElementById("platformInput");
  const officialCounter = document.getElementById("officialCounter");
  const suspiciousCounter = document.getElementById("suspiciousCounter");

  const analyseBtn = document.getElementById("analyseBtn");
  const resetBtn = document.getElementById("resetBtn");
  const copyBtn = document.getElementById("copyBtn");
  const status = document.getElementById("status");

  const emptyState = document.getElementById("emptyState");
  const resultContent = document.getElementById("resultContent");

  const scoreRing = document.getElementById("scoreRing");
  const scoreNumber = document.getElementById("scoreNumber");
  const riskBadge = document.getElementById("riskBadge");
  const resultHeading = document.getElementById("resultHeading");
  const resultSummary = document.getElementById("resultSummary");

  const officialDisplay = document.getElementById("officialDisplay");
  const suspiciousDisplay = document.getElementById("suspiciousDisplay");

  const levenshteinMetric = document.getElementById("levenshteinMetric");
  const jaroMetric = document.getElementById("jaroMetric");
  const distanceMetric = document.getElementById("distanceMetric");
  const canonicalMetric = document.getElementById("canonicalMetric");

  const patternList = document.getElementById("patternList");
  const recommendationList = document.getElementById("recommendationList");

  const rawOfficial = document.getElementById("rawOfficial");
  const rawSuspicious = document.getElementById("rawSuspicious");
  const unicodeOfficial = document.getElementById("unicodeOfficial");
  const unicodeSuspicious = document.getElementById("unicodeSuspicious");
  const compactOfficial = document.getElementById("compactOfficial");
  const compactSuspicious = document.getElementById("compactSuspicious");
  const canonicalOfficial = document.getElementById("canonicalOfficial");
  const canonicalSuspicious = document.getElementById("canonicalSuspicious");

  const CONFUSABLE_MAP = new Map([
    ["а", "a"], ["ɑ", "a"], ["α", "a"], ["Ꭺ", "a"],
    ["Ь", "b"], ["ь", "b"], ["β", "b"], ["в", "b"],
    ["с", "c"], ["ϲ", "c"], ["ⅽ", "c"],
    ["ԁ", "d"], ["ժ", "d"],
    ["е", "e"], ["ε", "e"], ["℮", "e"],
    ["ғ", "f"], ["ϝ", "f"],
    ["ɡ", "g"], ["ց", "g"],
    ["һ", "h"], ["н", "h"], ["η", "h"],
    ["і", "i"], ["ı", "i"], ["ι", "i"], ["ӏ", "i"], ["ⅼ", "i"],
    ["ј", "j"], ["ϳ", "j"],
    ["κ", "k"], ["к", "k"],
    ["ӏ", "l"], ["ⅼ", "l"], ["ℓ", "l"],
    ["м", "m"], ["ｍ", "m"],
    ["ո", "n"], ["п", "n"], ["η", "n"],
    ["о", "o"], ["ο", "o"], ["օ", "o"], ["૦", "o"],
    ["р", "p"], ["ρ", "p"],
    ["ԛ", "q"], ["գ", "q"],
    ["г", "r"], ["ᴦ", "r"],
    ["ѕ", "s"], ["ꜱ", "s"],
    ["т", "t"], ["τ", "t"],
    ["υ", "u"], ["ս", "u"],
    ["ѵ", "v"], ["ν", "v"],
    ["ԝ", "w"], ["ω", "w"],
    ["х", "x"], ["χ", "x"],
    ["у", "y"], ["ү", "y"], ["γ", "y"],
    ["ᴢ", "z"], ["Ζ", "z"]
  ]);

  const LEET_MAP = new Map([
    ["0", "o"],
    ["1", "i"],
    ["2", "z"],
    ["3", "e"],
    ["4", "a"],
    ["5", "s"],
    ["6", "g"],
    ["7", "t"],
    ["8", "b"],
    ["9", "g"]
  ]);

  let lastAnalysis = null;
  let profileCheckSequence = 0;

  /*
   * The live VirusTotal profile-reputation panel is created dynamically.
   * username.html does not need to be edited.
   */
  const profileApi = createProfileApiCard();

  officialInput.addEventListener("input", updateCounters);
  suspiciousInput.addEventListener("input", updateCounters);

  analyseBtn.addEventListener("click", analyseUsernames);
  resetBtn.addEventListener("click", resetTool);
  copyBtn.addEventListener("click", copyAnalysis);

  document.querySelectorAll(".example-btn").forEach((button) => {
    button.addEventListener("click", () => {
      officialInput.value = button.dataset.official || "";
      suspiciousInput.value = button.dataset.suspicious || "";
      updateCounters();
      analyseUsernames();
    });
  });

  [officialInput, suspiciousInput].forEach((input) => {
    input.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        analyseUsernames();
      }
    });
  });

  updateCounters();

  function analyseUsernames() {
    const official = officialInput.value.trim();
    const suspicious = suspiciousInput.value.trim();

    if (!official || !suspicious) {
      showStatus("Enter both the official and suspicious username.", "error");

      if (!official) {
        officialInput.focus();
      } else {
        suspiciousInput.focus();
      }

      return;
    }

    if (official.length < 2 || suspicious.length < 2) {
      showStatus("Each username must contain at least two characters.", "error");
      return;
    }

    const officialProfile = buildUsernameProfile(official);
    const suspiciousProfile = buildUsernameProfile(suspicious);

    const comparison = compareProfiles(
      officialProfile,
      suspiciousProfile,
      platformInput.value
    );

    lastAnalysis = comparison;
    renderAnalysis(comparison);

    showStatus(
      "Similarity analysis completed locally. Checking the profile URL reputation…"
    );

    runProfileReputationCheck(comparison);
  }

  function createProfileApiCard() {
    const card = document.createElement("section");
    card.className = "section-card";
    card.id = "profileReputationCard";
    card.hidden = true;

    const title = document.createElement("h3");
    title.textContent = "Live profile URL reputation";

    const description = document.createElement("p");
    description.style.marginBottom = "12px";
    description.style.color = "var(--muted)";
    description.style.fontFamily = '"OCR A Std", monospace';
    description.style.fontSize = "13px";
    description.style.lineHeight = "1.65";
    description.textContent =
      "Footprint checks the suspicious profile URL with VirusTotal as an additional safety signal. This does not confirm whether the account is genuine or fake.";

    const profileLink = document.createElement("a");
    profileLink.target = "_blank";
    profileLink.rel = "noopener noreferrer";
    profileLink.style.display = "block";
    profileLink.style.marginBottom = "12px";
    profileLink.style.color = "var(--purple)";
    profileLink.style.fontFamily = 'Consolas, "Courier New", monospace';
    profileLink.style.fontSize = "13px";
    profileLink.style.overflowWrap = "anywhere";
    profileLink.style.textDecoration = "none";

    const badge = document.createElement("span");
    badge.className = "risk-badge risk-moderate";
    badge.textContent = "Waiting";

    const summary = document.createElement("p");
    summary.style.margin = "3px 0 13px";
    summary.style.color = "var(--muted)";
    summary.style.fontFamily = '"OCR A Std", monospace';
    summary.style.fontSize = "13px";
    summary.style.lineHeight = "1.65";

    const metrics = document.createElement("div");
    metrics.className = "metrics-grid";
    metrics.style.marginBottom = "10px";

    const metricElements = {};

    [
      ["malicious", "Malicious"],
      ["suspicious", "Suspicious"],
      ["harmless", "Harmless"],
      ["undetected", "Undetected"]
    ].forEach(([key, label]) => {
      const box = document.createElement("div");
      box.className = "metric";

      const labelElement = document.createElement("span");
      labelElement.textContent = label;

      const valueElement = document.createElement("strong");
      valueElement.textContent = "—";

      box.append(labelElement, valueElement);
      metrics.appendChild(box);
      metricElements[key] = valueElement;
    });

    const note = document.createElement("p");
    note.style.marginTop = "9px";
    note.style.color = "var(--muted)";
    note.style.fontFamily = '"OCR A Std", monospace';
    note.style.fontSize = "11px";
    note.style.lineHeight = "1.6";
    note.textContent =
      "A clean URL result does not prove that the profile belongs to the claimed person. Continue verifying profile history, followers and trusted contact details.";

    card.append(
      title,
      description,
      profileLink,
      badge,
      summary,
      metrics,
      note
    );

    const resultActions =
      resultContent.querySelector(".result-actions");

    resultContent.insertBefore(
      card,
      resultActions || null
    );

    return {
      card,
      profileLink,
      badge,
      summary,
      metrics,
      metricElements,
      note
    };
  }

  function normaliseProfileUsername(value) {
    return String(value || "")
      .trim()
      .replace(/^@+/, "")
      .replace(/\s+/g, "");
  }

  function buildProfileUrl(platform, username) {
    const cleanUsername =
      normaliseProfileUsername(username);

    if (!cleanUsername) {
      return null;
    }

    const encoded = encodeURIComponent(cleanUsername);

    switch (platform) {
      case "Instagram":
        return `https://www.instagram.com/${encoded}/`;

      case "TikTok":
        return `https://www.tiktok.com/@${encoded}`;

      case "X / Twitter":
        return `https://x.com/${encoded}`;

      case "Facebook":
        return `https://www.facebook.com/${encoded}`;

      case "YouTube":
        return `https://www.youtube.com/@${encoded}`;

      default:
        return null;
    }
  }

  function sendRuntimeMessage(message) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        message,
        (response) => {
          if (chrome.runtime.lastError) {
            reject(
              new Error(
                chrome.runtime.lastError.message
              )
            );
            return;
          }

          resolve(response);
        }
      );
    });
  }

  async function runProfileReputationCheck(analysis) {
    const sequence = ++profileCheckSequence;

    const profileUrl = buildProfileUrl(
      analysis.platform,
      analysis.suspicious.raw
    );

    if (!profileUrl) {
      analysis.profileReputation = {
        status: "NOT_AVAILABLE",
        verdict: "UNKNOWN",
        profileUrl: null,
        message:
          "Choose Instagram, TikTok, X / Twitter, Facebook or YouTube to run the live profile URL check."
      };

      renderProfileReputation(
        analysis.profileReputation
      );

      showStatus(
        "Local similarity analysis completed. Select a supported platform for the live URL check.",
        "success"
      );

      return;
    }

    analysis.profileReputation = {
      status: "CHECKING",
      verdict: "UNKNOWN",
      profileUrl,
      malicious: 0,
      suspicious: 0,
      harmless: 0,
      undetected: 0,
      message:
        "Submitting the suspicious profile URL to VirusTotal…"
    };

    renderProfileReputation(
      analysis.profileReputation
    );

    try {
      const response = await sendRuntimeMessage({
        type: "CHECK_USERNAME_PROFILE",
        url: profileUrl,
        platform: analysis.platform,
        username: analysis.suspicious.raw
      });

      if (sequence !== profileCheckSequence) {
        return;
      }

      if (!response?.ok) {
        throw new Error(
          response?.message ||
          "The profile URL reputation check failed."
        );
      }

      analysis.profileReputation = {
        status: response.status || "UNKNOWN",
        verdict: response.verdict || "UNKNOWN",
        profileUrl,
        malicious: Number(response.malicious || 0),
        suspicious: Number(response.suspicious || 0),
        harmless: Number(response.harmless || 0),
        undetected: Number(response.undetected || 0),
        error: response.error || null,
        message: buildProfileResultMessage(response)
      };

      renderProfileReputation(
        analysis.profileReputation
      );

      if (
        response.verdict === "DANGER" ||
        response.verdict === "WARNING"
      ) {
        showStatus(
          "Local similarity analysis and live profile URL reputation check completed.",
          "error"
        );
      } else {
        showStatus(
          "Local similarity analysis and live profile URL reputation check completed.",
          "success"
        );
      }
    } catch (error) {
      if (sequence !== profileCheckSequence) {
        return;
      }

      analysis.profileReputation = {
        status: "UNAVAILABLE",
        verdict: "UNKNOWN",
        profileUrl,
        malicious: 0,
        suspicious: 0,
        harmless: 0,
        undetected: 0,
        error: error?.message || "Unknown API error",
        message:
          "VirusTotal was unavailable. The local username similarity result remains valid."
      };

      renderProfileReputation(
        analysis.profileReputation
      );

      showStatus(
        "Similarity analysis completed locally. The live profile URL check was unavailable.",
        "success"
      );
    }
  }

  function buildProfileResultMessage(result) {
    const verdict = String(
      result?.verdict || "UNKNOWN"
    ).toUpperCase();

    if (verdict === "DANGER") {
      return "VirusTotal reported multiple malicious detections for this profile URL. Avoid opening links or sharing sensitive information.";
    }

    if (verdict === "WARNING") {
      return "VirusTotal reported a malicious or suspicious detection for this profile URL. Treat the profile with additional caution.";
    }

    if (verdict === "SAFE") {
      return "VirusTotal reported no malicious or suspicious URL detections. This does not confirm that the account is official.";
    }

    if (result?.status === "API_KEY_MISSING") {
      return "Add a valid VirusTotal API key in background.js to enable the live profile URL check.";
    }

    return "VirusTotal could not provide a completed result. The local username similarity analysis is still available.";
  }

  function renderProfileReputation(result) {
    profileApi.card.hidden = false;

    const profileUrl = result?.profileUrl || "";

    if (profileUrl) {
      profileApi.profileLink.hidden = false;
      profileApi.profileLink.href = profileUrl;
      profileApi.profileLink.textContent =
        `Profile URL: ${profileUrl}`;
    } else {
      profileApi.profileLink.hidden = true;
      profileApi.profileLink.removeAttribute("href");
      profileApi.profileLink.textContent = "";
    }

    const verdict = String(
      result?.verdict || "UNKNOWN"
    ).toUpperCase();

    if (result?.status === "CHECKING") {
      profileApi.badge.className =
        "risk-badge risk-moderate";
      profileApi.badge.textContent =
        "Checking VirusTotal";

      profileApi.summary.textContent =
        result.message ||
        "Checking the profile URL…";
    } else if (verdict === "DANGER") {
      profileApi.badge.className =
        "risk-badge risk-high";
      profileApi.badge.textContent =
        "Dangerous URL reputation";

      profileApi.summary.textContent =
        result.message;
    } else if (verdict === "WARNING") {
      profileApi.badge.className =
        "risk-badge risk-elevated";
      profileApi.badge.textContent =
        "URL requires caution";

      profileApi.summary.textContent =
        result.message;
    } else if (verdict === "SAFE") {
      profileApi.badge.className =
        "risk-badge risk-low";
      profileApi.badge.textContent =
        "No URL detections reported";

      profileApi.summary.textContent =
        result.message;
    } else {
      profileApi.badge.className =
        "risk-badge risk-moderate";
      profileApi.badge.textContent =
        result?.status === "NOT_AVAILABLE"
          ? "Platform required"
          : "Live check unavailable";

      profileApi.summary.textContent =
        result?.message ||
        "The live profile URL check is unavailable.";
    }

    const showMetrics =
      result?.status !== "CHECKING" &&
      result?.status !== "NOT_AVAILABLE" &&
      result?.status !== "UNAVAILABLE";

    profileApi.metrics.hidden = !showMetrics;

    profileApi.metricElements.malicious.textContent =
      showMetrics
        ? String(Number(result?.malicious || 0))
        : "—";

    profileApi.metricElements.suspicious.textContent =
      showMetrics
        ? String(Number(result?.suspicious || 0))
        : "—";

    profileApi.metricElements.harmless.textContent =
      showMetrics
        ? String(Number(result?.harmless || 0))
        : "—";

    profileApi.metricElements.undetected.textContent =
      showMetrics
        ? String(Number(result?.undetected || 0))
        : "—";
  }

  function buildUsernameProfile(value) {
    const raw = value.trim();
    const lower = raw.toLocaleLowerCase("en");

    let unicodeNormalized = lower.normalize("NFKC");
    let confusableCount = 0;
    let leetCount = 0;

    unicodeNormalized = Array.from(unicodeNormalized)
      .map((character) => {
        if (CONFUSABLE_MAP.has(character)) {
          confusableCount += 1;
          return CONFUSABLE_MAP.get(character);
        }

        return character;
      })
      .join("");

    unicodeNormalized = unicodeNormalized
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "");

    const compact = unicodeNormalized.replace(/[\s._\-–—]+/g, "");

    const leetNormalized = Array.from(compact)
      .map((character) => {
        if (LEET_MAP.has(character)) {
          leetCount += 1;
          return LEET_MAP.get(character);
        }

        return character;
      })
      .join("");

    const canonical = leetNormalized
      .replace(/[^a-z0-9]/g, "")
      .replace(/(.)\1{2,}/g, "$1");

    return {
      raw,
      lower,
      unicodeNormalized,
      compact,
      canonical,
      confusableCount,
      leetCount,
      separatorCount: (lower.match(/[\s._\-–—]/g) || []).length,
      repeatedRun: /(.)\1{2,}/.test(leetNormalized)
    };
  }

  function compareProfiles(official, suspicious, platform) {
    const officialCanonical = official.canonical || official.compact || official.lower;
    const suspiciousCanonical =
      suspicious.canonical || suspicious.compact || suspicious.lower;

    const distance = levenshteinDistance(
      officialCanonical,
      suspiciousCanonical
    );

    const maximumLength = Math.max(
      officialCanonical.length,
      suspiciousCanonical.length,
      1
    );

    const levenshteinSimilarity = 1 - distance / maximumLength;
    const jaroWinklerScore = jaroWinkler(
      officialCanonical,
      suspiciousCanonical
    );

    const patterns = detectPatterns(
      official,
      suspicious,
      distance,
      levenshteinSimilarity,
      jaroWinklerScore
    );

    const score = calculateRiskScore(
      official,
      suspicious,
      levenshteinSimilarity,
      jaroWinklerScore,
      patterns
    );

    const risk = classifyRisk(score);
    const recommendations = buildRecommendations(risk, patterns);

    return {
      official,
      suspicious,
      platform,
      distance,
      levenshteinSimilarity,
      jaroWinklerScore,
      patterns,
      score,
      risk,
      recommendations,
      analysedAt: new Date()
    };
  }

  function detectPatterns(
    official,
    suspicious,
    distance,
    levenshteinSimilarity,
    jaroWinklerScore
  ) {
    const patterns = [];

    const rawExact = official.lower === suspicious.lower;
    const canonicalExact =
      official.canonical.length > 0 &&
      official.canonical === suspicious.canonical;

    if (rawExact) {
      patterns.push({
        id: "exact",
        severity: 18,
        label: "Exact username match",
        detail:
          "Both usernames are identical after letter-case normalization. Confirm that the account belongs to the expected person."
      });
    }

    if (canonicalExact && !rawExact) {
      patterns.push({
        id: "canonical-collision",
        severity: 22,
        label: "Normalized usernames are identical",
        detail:
          "The visible usernames differ, but separators, number substitutions or look-alike characters reduce them to the same canonical form."
      });
    }

    if (suspicious.confusableCount > 0) {
      patterns.push({
        id: "homograph",
        severity: 15,
        label: "Unicode homograph characters detected",
        detail:
          `${suspicious.confusableCount} look-alike character(s) were converted to their Latin equivalent during analysis.`
      });
    }

    if (suspicious.leetCount > 0) {
      patterns.push({
        id: "leet",
        severity: 11,
        label: "Number-to-letter substitution detected",
        detail:
          `${suspicious.leetCount} number character(s) resemble letters, such as 0/o, 1/i or 3/e.`
      });
    }

    if (
      official.separatorCount !== suspicious.separatorCount &&
      (official.separatorCount > 0 || suspicious.separatorCount > 0)
    ) {
      patterns.push({
        id: "separator",
        severity: 7,
        label: "Separator modification detected",
        detail:
          "Dots, underscores, hyphens or spaces were added or removed while preserving the main username."
      });
    }

    if (suspicious.repeatedRun && !official.repeatedRun) {
      patterns.push({
        id: "repeat",
        severity: 6,
        label: "Repeated-character variation detected",
        detail:
          "The checked username contains a repeated character sequence that is not present in the official username."
      });
    }

    const shorter =
      official.canonical.length <= suspicious.canonical.length
        ? official.canonical
        : suspicious.canonical;

    const longer =
      official.canonical.length > suspicious.canonical.length
        ? official.canonical
        : suspicious.canonical;

    const lengthDifference = longer.length - shorter.length;

    if (
      shorter.length >= 3 &&
      longer.includes(shorter) &&
      lengthDifference > 0 &&
      lengthDifference <= 12
    ) {
      const prefix = longer.endsWith(shorter);
      const suffix = longer.startsWith(shorter);

      patterns.push({
        id: "affix",
        severity: 8,
        label: "Prefix or suffix added",
        detail: prefix
          ? "Extra characters were added before the main username."
          : suffix
            ? "Extra characters were added after the main username."
            : "The official username appears inside the checked username with extra surrounding characters."
      });
    }

    const prefixLength = commonPrefixLength(
      official.canonical,
      suspicious.canonical
    );

    const prefixRatio =
      prefixLength /
      Math.max(
        1,
        Math.min(
          official.canonical.length,
          suspicious.canonical.length
        )
      );

    if (
      prefixLength >= 3 &&
      prefixRatio >= 0.55 &&
      !canonicalExact
    ) {
      patterns.push({
        id: "shared-prefix",
        severity: 5,
        label: "Strong shared prefix",
        detail:
          `The first ${prefixLength} canonical character(s) match, which may make the usernames look related at a glance.`
      });
    }

    if (distance > 0 && distance <= 2) {
      patterns.push({
        id: "small-edit",
        severity: 10,
        label: "Only a small number of edits",
        detail:
          `Only ${distance} insertion, deletion or substitution is required to transform one canonical username into the other.`
      });
    }

    if (
      isSingleAdjacentTransposition(
        official.canonical,
        suspicious.canonical
      )
    ) {
      patterns.push({
        id: "transposition",
        severity: 9,
        label: "Adjacent characters swapped",
        detail:
          "Two neighboring characters appear to have been reversed, a common typo-style impersonation pattern."
      });
    }

    if (
      levenshteinSimilarity >= 0.85 ||
      jaroWinklerScore >= 0.9
    ) {
      patterns.push({
        id: "algorithmic-similarity",
        severity: 7,
        label: "High algorithmic resemblance",
        detail:
          "The combined similarity algorithms indicate that the username structures are closely related."
      });
    }

    return deduplicatePatterns(patterns);
  }

  function calculateRiskScore(
    official,
    suspicious,
    levenshteinSimilarity,
    jaroWinklerScore,
    patterns
  ) {
    let score =
      levenshteinSimilarity * 52 +
      jaroWinklerScore * 38;

    const patternAdjustment = patterns.reduce(
      (total, pattern) => total + pattern.severity,
      0
    );

    score += Math.min(24, patternAdjustment);

    const rawExact = official.lower === suspicious.lower;
    const canonicalExact =
      official.canonical.length > 0 &&
      official.canonical === suspicious.canonical;

    if (rawExact) {
      score = 100;
    } else if (canonicalExact) {
      score = Math.max(score, 97);
    }

    const shortestLength = Math.min(
      official.canonical.length,
      suspicious.canonical.length
    );

    if (shortestLength <= 3 && !canonicalExact) {
      score *= 0.84;
    }

    return Math.max(0, Math.min(100, Math.round(score)));
  }

  function classifyRisk(score) {
    if (score >= 90) {
      return {
        level: "High",
        badge: "High impersonation risk",
        heading: "Very close resemblance detected",
        cssClass: "risk-high",
        colour: "var(--danger)",
        summary:
          "The checked username strongly resembles the official username and contains patterns commonly associated with impersonation."
      };
    }

    if (score >= 75) {
      return {
        level: "Elevated",
        badge: "Elevated risk",
        heading: "Suspicious resemblance detected",
        cssClass: "risk-elevated",
        colour: "var(--elevated)",
        summary:
          "Several structural similarities or modification patterns were detected. Verify the account before interacting."
      };
    }

    if (score >= 55) {
      return {
        level: "Moderate",
        badge: "Moderate risk",
        heading: "Some resemblance detected",
        cssClass: "risk-moderate",
        colour: "var(--warning)",
        summary:
          "The usernames share some characteristics, but similarity alone is insufficient to determine impersonation."
      };
    }

    return {
      level: "Low",
      badge: "Low similarity risk",
      heading: "Low resemblance detected",
      cssClass: "risk-low",
      colour: "var(--safe)",
      summary:
        "The usernames are not strongly similar according to the current pattern-based checks. Continue using normal account-verification practices."
    };
  }

  function buildRecommendations(risk, patterns) {
    const recommendations = [];

    if (risk.level === "High" || risk.level === "Elevated") {
      recommendations.push(
        "Do not share passwords, verification codes, payment details or personal documents with the checked account.",
        "Open the known official profile through a saved link, verified website or previous trusted conversation.",
        "Compare the profile creation date, post history, followers, biography and contact information.",
        "Contact the person or organisation through another trusted channel before taking action."
      );
    } else if (risk.level === "Moderate") {
      recommendations.push(
        "Review the account profile and recent activity before accepting messages or requests.",
        "Check whether the official account publicly lists alternative usernames.",
        "Avoid urgent financial requests until the identity is confirmed through another channel."
      );
    } else {
      recommendations.push(
        "Similarity risk is low, but still check profile history and context before trusting an unfamiliar account.",
        "Treat unsolicited links, urgent requests and requests for sensitive information cautiously."
      );
    }

    if (patterns.some((pattern) => pattern.id === "homograph")) {
      recommendations.push(
        "Copy the username into a plain-text field and inspect each character because some Unicode letters may only look like Latin letters."
      );
    }

    return [...new Set(recommendations)];
  }

  function renderAnalysis(analysis) {
    emptyState.hidden = true;
    resultContent.hidden = false;

    const scoreAngle = Math.round((analysis.score / 100) * 360);

    scoreRing.style.setProperty("--score", `${scoreAngle}deg`);
    scoreRing.style.setProperty("--score-color", analysis.risk.colour);
    scoreNumber.textContent = String(analysis.score);

    riskBadge.className = `risk-badge ${analysis.risk.cssClass}`;
    riskBadge.textContent = analysis.risk.badge;
    resultHeading.textContent = analysis.risk.heading;
    resultSummary.textContent = analysis.risk.summary;

    officialDisplay.textContent = analysis.official.raw;
    suspiciousDisplay.textContent = analysis.suspicious.raw;

    levenshteinMetric.textContent =
      `${Math.round(analysis.levenshteinSimilarity * 100)}%`;

    jaroMetric.textContent =
      `${Math.round(analysis.jaroWinklerScore * 100)}%`;

    distanceMetric.textContent = String(analysis.distance);

    canonicalMetric.textContent =
      analysis.official.canonical === analysis.suspicious.canonical
        ? "Yes"
        : "No";

    rawOfficial.textContent = analysis.official.raw;
    rawSuspicious.textContent = analysis.suspicious.raw;
    unicodeOfficial.textContent =
      analysis.official.unicodeNormalized || "—";
    unicodeSuspicious.textContent =
      analysis.suspicious.unicodeNormalized || "—";
    compactOfficial.textContent = analysis.official.compact || "—";
    compactSuspicious.textContent = analysis.suspicious.compact || "—";
    canonicalOfficial.textContent = analysis.official.canonical || "—";
    canonicalSuspicious.textContent =
      analysis.suspicious.canonical || "—";

    renderPatterns(analysis.patterns);
    renderRecommendations(analysis.recommendations);
  }

  function renderPatterns(patterns) {
    patternList.innerHTML = "";

    if (patterns.length === 0) {
      const message = document.createElement("li");
      message.className = "no-patterns";
      message.textContent =
        "No specific impersonation modification pattern was detected.";
      patternList.appendChild(message);
      return;
    }

    patterns.forEach((pattern) => {
      const item = document.createElement("li");
      item.className = "pattern-item";

      const icon = document.createElement("div");
      icon.className = "pattern-icon";
      icon.textContent = "!";

      const content = document.createElement("div");
      const strong = document.createElement("strong");
      const description = document.createElement("div");

      strong.textContent = pattern.label;
      strong.style.color = "var(--text)";
      description.textContent = pattern.detail;

      content.append(strong, description);
      item.append(icon, content);
      patternList.appendChild(item);
    });
  }

  function renderRecommendations(recommendations) {
    recommendationList.innerHTML = "";

    recommendations.forEach((recommendation) => {
      const item = document.createElement("li");
      item.className = "recommendation-item";

      const icon = document.createElement("div");
      icon.className = "recommendation-icon";
      icon.textContent = "✓";

      const text = document.createElement("div");
      text.textContent = recommendation;

      item.append(icon, text);
      recommendationList.appendChild(item);
    });
  }

  async function copyAnalysis() {
    if (!lastAnalysis) {
      showStatus("Run a comparison before copying the summary.", "error");
      return;
    }

    const patternText = lastAnalysis.patterns.length
      ? lastAnalysis.patterns
          .map((pattern) => `- ${pattern.label}: ${pattern.detail}`)
          .join("\n")
      : "- No specific modification patterns detected.";

    const recommendationText = lastAnalysis.recommendations
      .map((recommendation) => `- ${recommendation}`)
      .join("\n");

    const summary = [
      "FOOTPRINT USERNAME SIMILARITY ANALYSIS",
      "",
      `Official username: ${lastAnalysis.official.raw}`,
      `Checked username: ${lastAnalysis.suspicious.raw}`,
      `Platform: ${lastAnalysis.platform}`,
      `Risk score: ${lastAnalysis.score}/100`,
      `Risk level: ${lastAnalysis.risk.level}`,
      `Levenshtein similarity: ${Math.round(lastAnalysis.levenshteinSimilarity * 100)}%`,
      `Jaro-Winkler similarity: ${Math.round(lastAnalysis.jaroWinklerScore * 100)}%`,
      `Edit distance: ${lastAnalysis.distance}`,
      "",
      "Detected patterns:",
      patternText,
      "",
      "Recommended checks:",
      recommendationText,
      "",
      "Live profile URL reputation:",
      formatProfileReputationForCopy(
        lastAnalysis.profileReputation
      ),
      "",
      "Note: The similarity score and URL reputation result are early-warning indicators and are not proof that an account is fraudulent."
    ].join("\n");

    try {
      await navigator.clipboard.writeText(summary);
      showStatus("Analysis summary copied.", "success");
    } catch (error) {
      const textArea = document.createElement("textarea");
      textArea.value = summary;
      textArea.style.position = "fixed";
      textArea.style.opacity = "0";

      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand("copy");
      textArea.remove();

      showStatus("Analysis summary copied.", "success");
    }
  }

  function formatProfileReputationForCopy(result) {
    if (!result) {
      return "- Live check not completed.";
    }

    const lines = [];

    if (result.profileUrl) {
      lines.push(`- Profile URL: ${result.profileUrl}`);
    }

    lines.push(
      `- Status: ${result.status || "UNKNOWN"}`,
      `- Verdict: ${result.verdict || "UNKNOWN"}`
    );

    if (
      result.status !== "NOT_AVAILABLE" &&
      result.status !== "UNAVAILABLE"
    ) {
      lines.push(
        `- Malicious detections: ${Number(result.malicious || 0)}`,
        `- Suspicious detections: ${Number(result.suspicious || 0)}`
      );
    }

    if (result.message) {
      lines.push(`- Explanation: ${result.message}`);
    }

    return lines.join("\\n");
  }

  function resetTool() {
    officialInput.value = "";
    suspiciousInput.value = "";
    platformInput.value = "Not specified";

    profileCheckSequence += 1;
    lastAnalysis = null;
    profileApi.card.hidden = true;
    resultContent.hidden = true;
    emptyState.hidden = false;

    updateCounters();
    showStatus("Enter two usernames to begin.");
    officialInput.focus();
  }

  function updateCounters() {
    officialCounter.textContent =
      `${officialInput.value.length} / 64`;

    suspiciousCounter.textContent =
      `${suspiciousInput.value.length} / 64`;
  }

  function showStatus(message, type = "") {
    status.textContent = message;
    status.className = `status${type ? ` ${type}` : ""}`;
  }

  function levenshteinDistance(first, second) {
    if (first === second) {
      return 0;
    }

    if (first.length === 0) {
      return second.length;
    }

    if (second.length === 0) {
      return first.length;
    }

    let previousRow = Array.from(
      { length: second.length + 1 },
      (_, index) => index
    );

    let currentRow = new Array(second.length + 1);

    for (let firstIndex = 1; firstIndex <= first.length; firstIndex += 1) {
      currentRow[0] = firstIndex;

      for (
        let secondIndex = 1;
        secondIndex <= second.length;
        secondIndex += 1
      ) {
        const substitutionCost =
          first[firstIndex - 1] === second[secondIndex - 1]
            ? 0
            : 1;

        currentRow[secondIndex] = Math.min(
          currentRow[secondIndex - 1] + 1,
          previousRow[secondIndex] + 1,
          previousRow[secondIndex - 1] + substitutionCost
        );
      }

      [previousRow, currentRow] = [currentRow, previousRow];
    }

    return previousRow[second.length];
  }

  function jaroSimilarity(first, second) {
    if (first === second) {
      return 1;
    }

    if (!first.length || !second.length) {
      return 0;
    }

    const matchDistance =
      Math.max(
        0,
        Math.floor(Math.max(first.length, second.length) / 2) - 1
      );

    const firstMatches = new Array(first.length).fill(false);
    const secondMatches = new Array(second.length).fill(false);

    let matches = 0;

    for (let firstIndex = 0; firstIndex < first.length; firstIndex += 1) {
      const start = Math.max(0, firstIndex - matchDistance);
      const end = Math.min(
        firstIndex + matchDistance + 1,
        second.length
      );

      for (
        let secondIndex = start;
        secondIndex < end;
        secondIndex += 1
      ) {
        if (secondMatches[secondIndex]) {
          continue;
        }

        if (first[firstIndex] !== second[secondIndex]) {
          continue;
        }

        firstMatches[firstIndex] = true;
        secondMatches[secondIndex] = true;
        matches += 1;
        break;
      }
    }

    if (matches === 0) {
      return 0;
    }

    let transpositions = 0;
    let secondIndex = 0;

    for (let firstIndex = 0; firstIndex < first.length; firstIndex += 1) {
      if (!firstMatches[firstIndex]) {
        continue;
      }

      while (!secondMatches[secondIndex]) {
        secondIndex += 1;
      }

      if (first[firstIndex] !== second[secondIndex]) {
        transpositions += 1;
      }

      secondIndex += 1;
    }

    transpositions /= 2;

    return (
      matches / first.length +
      matches / second.length +
      (matches - transpositions) / matches
    ) / 3;
  }

  function jaroWinkler(first, second) {
    const jaro = jaroSimilarity(first, second);

    let prefixLength = 0;
    const maximumPrefix = Math.min(4, first.length, second.length);

    while (
      prefixLength < maximumPrefix &&
      first[prefixLength] === second[prefixLength]
    ) {
      prefixLength += 1;
    }

    const scalingFactor = 0.1;

    return jaro +
      prefixLength * scalingFactor * (1 - jaro);
  }

  function commonPrefixLength(first, second) {
    const maximum = Math.min(first.length, second.length);
    let index = 0;

    while (
      index < maximum &&
      first[index] === second[index]
    ) {
      index += 1;
    }

    return index;
  }

  function isSingleAdjacentTransposition(first, second) {
    if (
      first.length !== second.length ||
      first.length < 2 ||
      first === second
    ) {
      return false;
    }

    const differences = [];

    for (let index = 0; index < first.length; index += 1) {
      if (first[index] !== second[index]) {
        differences.push(index);
      }
    }

    if (
      differences.length !== 2 ||
      differences[1] !== differences[0] + 1
    ) {
      return false;
    }

    const firstIndex = differences[0];
    const secondIndex = differences[1];

    return (
      first[firstIndex] === second[secondIndex] &&
      first[secondIndex] === second[firstIndex]
    );
  }

  function deduplicatePatterns(patterns) {
    const seen = new Set();

    return patterns.filter((pattern) => {
      if (seen.has(pattern.id)) {
        return false;
      }

      seen.add(pattern.id);
      return true;
    });
  }
});
