document.addEventListener("DOMContentLoaded", () => {
  "use strict";

  const params = new URLSearchParams(window.location.search);
  const tabId = Number(params.get("tabId"));

  const riskBadge = document.getElementById("riskBadge");
  const heading = document.getElementById("heading");
  const summary = document.getElementById("summary");
  const websiteUrl = document.getElementById("websiteUrl");
  const reasonList = document.getElementById("reasonList");
  const continueBtn = document.getElementById("continueBtn");
  const leaveBtn = document.getElementById("leaveBtn");
  const status = document.getElementById("status");

  continueBtn.addEventListener("click", () => {
    sendDecision("CONTINUE");
  });

  leaveBtn.addEventListener("click", () => {
    sendDecision("LEAVE");
  });

  if (!Number.isFinite(tabId)) {
    showError("The website tab ID is invalid.");
    disableButtons();
    return;
  }

  loadWarning();

  function loadWarning() {
    chrome.storage.local.get(
      { pendingSiteDecisions: {} },
      (data) => {
        if (chrome.runtime.lastError) {
          showError(chrome.runtime.lastError.message);
          disableButtons();
          return;
        }

        const record =
          data.pendingSiteDecisions?.[String(tabId)];

        if (!record) {
          showError(
            "This website warning is no longer active."
          );
          disableButtons();
          return;
        }

        renderWarning(record);
      }
    );
  }

  function renderWarning(record) {
    const risk =
      String(record.risk || "WARNING").toUpperCase();

    const isDanger = risk === "DANGER";

    riskBadge.textContent = risk;
    riskBadge.className =
      `risk ${isDanger ? "risk-danger" : "risk-warning"}`;

    heading.textContent = isDanger
      ? "Dangerous website detected"
      : "Suspicious website detected";

    summary.textContent = isDanger
      ? "Footprint detected high-risk indicators. Avoid entering passwords, personal information or payment details."
      : "Footprint detected one or more warning indicators. Review the reasons before continuing.";

    websiteUrl.textContent =
      record.url || "Unknown website";

    reasonList.replaceChildren();

    const reasons = Array.isArray(record.reasons)
      ? record.reasons
      : [];

    if (reasons.length === 0) {
      const item = document.createElement("li");
      item.textContent =
        "The website requires additional caution.";
      reasonList.appendChild(item);
      return;
    }

    reasons.forEach((reason) => {
      const item = document.createElement("li");
      item.textContent = String(reason);
      reasonList.appendChild(item);
    });
  }

  function sendDecision(action) {
    disableButtons();

    status.className = "status";
    status.textContent =
      action === "CONTINUE"
        ? "Allowing this website…"
        : "Moving away from this website…";

    chrome.runtime.sendMessage(
      {
        type: "SITE_SAFETY_DECISION",
        tabId,
        action
      },
      (response) => {
        if (chrome.runtime.lastError) {
          showError(chrome.runtime.lastError.message);
          enableButtons();
          return;
        }

        if (!response?.ok) {
          showError(
            response?.message ||
            "The website decision failed."
          );
          enableButtons();
          return;
        }

        status.className = "status success";
        status.textContent = response.message;

        window.setTimeout(() => {
          window.close();
        }, 700);
      }
    );
  }

  function disableButtons() {
    continueBtn.disabled = true;
    leaveBtn.disabled = true;
  }

  function enableButtons() {
    continueBtn.disabled = false;
    leaveBtn.disabled = false;
  }

  function showError(message) {
    status.className = "status error";
    status.textContent = message;
  }
});
