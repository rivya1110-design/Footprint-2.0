document.addEventListener("DOMContentLoaded", () => {
  "use strict";

  const params = new URLSearchParams(window.location.search);
  const downloadId = Number(params.get("downloadId"));

  const riskBadge = document.getElementById("riskBadge");
  const heading = document.getElementById("heading");
  const summary = document.getElementById("summary");
  const filename = document.getElementById("filename");
  const source = document.getElementById("source");
  const reasonList = document.getElementById("reasonList");
  const proceedBtn = document.getElementById("proceedBtn");
  const cancelBtn = document.getElementById("cancelBtn");
  const status = document.getElementById("status");

  let lastRecord = null;
  let safeCloseTimer = null;

  proceedBtn.addEventListener("click", () => {
    submitDecision("PROCEED");
  });

  cancelBtn.addEventListener("click", () => {
    submitDecision("CANCEL");
  });

  if (!Number.isFinite(downloadId)) {
    showError("The download ID is invalid.");
    disableButtons();
    return;
  }

  loadPendingDecision();

  chrome.storage.onChanged.addListener(
    (changes, areaName) => {
      if (
        areaName !== "local" ||
        !changes.pendingDownloadDecisions
      ) {
        return;
      }

      const record =
        changes.pendingDownloadDecisions
          .newValue?.[String(downloadId)];

      if (record) {
        renderRecord(record);
        return;
      }

      /*
       * The background removes the pending record after a SAFE result or
       * after the user makes a decision.
       */
      if (lastRecord?.risk === "SAFE") {
        showSafeAndClose();
      }
    }
  );

  function loadPendingDecision() {
    chrome.storage.local.get(
      { pendingDownloadDecisions: {} },
      (data) => {
        if (chrome.runtime.lastError) {
          showError(chrome.runtime.lastError.message);
          disableButtons();
          return;
        }

        const record =
          data.pendingDownloadDecisions?.[
            String(downloadId)
          ];

        if (!record) {
          showError(
            "This download is no longer waiting for a decision."
          );
          disableButtons();
          return;
        }

        renderRecord(record);
      }
    );
  }

  function renderRecord(record) {
    lastRecord = record;

    const risk = String(
      record.risk || "CHECKING"
    ).toUpperCase();

    const stage = String(
      record.stage || "ANALYSING"
    ).toUpperCase();

    filename.textContent =
      record.filename || "Unknown file";

    source.textContent =
      getHost(record.url);

    renderReasons(record.reasons);

    if (risk === "SAFE" || stage === "SAFE") {
      riskBadge.textContent = "SAFE";
      riskBadge.className = "risk risk-safe";
      heading.textContent = "Download appears safe";
      summary.textContent =
        "Footprint completed the checks and resumed the download automatically.";

      disableButtons();
      status.className = "status success";
      status.textContent = "Download resumed.";

      window.clearTimeout(safeCloseTimer);
      safeCloseTimer = window.setTimeout(() => {
        window.close();
      }, 1100);

      return;
    }

    if (stage === "ANALYSING") {
      riskBadge.textContent =
        risk === "DANGER"
          ? "DANGER — CHECKING"
          : risk === "WARNING"
            ? "WARNING — CHECKING"
            : "CHECKING";

      riskBadge.className =
        risk === "DANGER"
          ? "risk risk-danger"
          : risk === "WARNING"
            ? "risk risk-warning"
            : "risk risk-checking";

      heading.textContent =
        risk === "DANGER"
          ? "High-risk file detected"
          : risk === "WARNING"
            ? "Download needs caution"
            : "Checking download safety";

      summary.textContent =
        "Footprint paused the download immediately. VirusTotal and browser safety checks are still running.";

      proceedBtn.disabled = true;
      cancelBtn.disabled = false;

      status.className = "status";
      status.textContent =
        "Please wait for the analysis to finish.";

      return;
    }

    const isDanger = risk === "DANGER";

    riskBadge.textContent = risk;
    riskBadge.className =
      `risk ${isDanger ? "risk-danger" : "risk-warning"}`;

    heading.textContent = isDanger
      ? "Dangerous download detected"
      : "Suspicious download detected";

    summary.textContent = isDanger
      ? "Footprint detected high-risk indicators. Continue only when you completely trust this file."
      : "Footprint detected one or more warning indicators. Review the reasons before continuing.";

    proceedBtn.disabled =
      record.allowProceed !== true;

    cancelBtn.disabled = false;

    status.className = "status";
    status.textContent =
      record.allowProceed === true
        ? "Choose whether to proceed or cancel."
        : "Finishing the safety checks…";
  }

  function renderReasons(reasonsValue) {
    reasonList.replaceChildren();

    const reasons = Array.isArray(reasonsValue)
      ? reasonsValue
      : [];

    if (reasons.length === 0) {
      const item = document.createElement("li");
      item.textContent =
        "Footprint is analysing this download.";
      reasonList.appendChild(item);
      return;
    }

    reasons.forEach((reason) => {
      const item = document.createElement("li");
      item.textContent = String(reason);
      reasonList.appendChild(item);
    });
  }

  function submitDecision(action) {
    disableButtons();

    status.className = "status";
    status.textContent =
      action === "PROCEED"
        ? "Trying to resume the download…"
        : "Cancelling the download…";

    chrome.runtime.sendMessage(
      {
        type: "DOWNLOAD_SAFETY_DECISION",
        downloadId,
        action
      },
      (response) => {
        if (chrome.runtime.lastError) {
          showError(chrome.runtime.lastError.message);
          enableDecisionButtons();
          return;
        }

        if (!response?.ok) {
          showError(
            response?.message ||
            "The download decision failed."
          );
          enableDecisionButtons();
          return;
        }

        status.className = "status success";
        status.textContent = response.message;

        window.setTimeout(() => {
          window.close();
        }, 700);
      }
    );
  }

  function showSafeAndClose() {
    riskBadge.textContent = "SAFE";
    riskBadge.className = "risk risk-safe";
    heading.textContent = "Download appears safe";
    summary.textContent =
      "Footprint completed the checks and resumed the download automatically.";
    disableButtons();

    status.className = "status success";
    status.textContent = "Download resumed.";

    window.setTimeout(() => {
      window.close();
    }, 900);
  }

  function getHost(value) {
    try {
      return (
        new URL(value).hostname ||
        value ||
        "Unknown source"
      );
    } catch (_error) {
      return value || "Unknown source";
    }
  }

  function disableButtons() {
    proceedBtn.disabled = true;
    cancelBtn.disabled = true;
  }

  function enableDecisionButtons() {
    proceedBtn.disabled =
      lastRecord?.allowProceed !== true;

    cancelBtn.disabled = false;
  }

  function showError(message) {
    status.className = "status error";
    status.textContent = message;
  }
});
