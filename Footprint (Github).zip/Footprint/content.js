// For scaning URLs and suspicious keywords 
// Auto scan and send results to popup.js 
// Check for sus sites w VirusTotal API, URL pattern checking, login keyword checking

// installation guard so scanner dont install >1 
if (!globalThis.__footprintScannerInstalled) {
    globalThis.__footprintScannerInstalled = true;

    // wait for messages and check message and webpage info
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
        if (message.type !== "SCAN_PAGE") return undefined;

        const pageText = String(document.body?.innerText || "").toLowerCase();
        const pageUrl = window.location.href;
        const flags = [];

        //request to check URL reputation, checking for connection, VirusTotal result
        chrome.runtime.sendMessage({ type: "CHECK_URL", url: pageUrl }, (apiResponse) => {
            if (chrome.runtime.lastError) {
                console.warn("Remote URL check unavailable:", chrome.runtime.lastError.message);
            }

            if (apiResponse?.result === "malicious") {
                flags.push("⚠️ VirusTotal: Malicious URL detected");
            }

            // convert URL to object
            let parsedUrl = null;
            try {
                parsedUrl = new URL(pageUrl);
            } catch (_error) {
                // URL-pattern below will use the raw URL if invalid, so won't stop running 
            }

            // extracting domain name to find sus http,ip and login domains
            const hostname = String(parsedUrl?.hostname || "").toLowerCase();

            if (parsedUrl?.protocol === "http:" && !["localhost", "127.0.0.1"].includes(hostname)) {
                flags.push("⚠️ Site is not using HTTPS (insecure connection)");
            }

            if (/^(?:\d{1,3}\.){3}\d{1,3}$/.test(hostname)) {
                flags.push("URL uses raw IP address (suspicious)");
            }

            if (/login.*-.*\.(xyz|top|click|tk|ml|ga)$/i.test(hostname)) {
                flags.push("Suspicious login domain");
            }

            // stores well known brand domains, protect them and find if sus
            const protectedBrands = [
                { brand: "shopee", official: ["shopee.com"] },
                { brand: "apple", official: ["apple.com"] },
                { brand: "microsoft", official: ["microsoft.com", "live.com"] },
                { brand: "google", official: ["google.com", "googleusercontent.com"] }
            ];

            protectedBrands.forEach(({ brand, official }) => {
                const mentionsBrand = hostname.includes(brand);
                const isOfficial = official.some(
                    (domain) => hostname === domain || hostname.endsWith(`.${domain}`)
                );

                if (mentionsBrand && !isOfficial) {
                    flags.push(`Brand name “${brand}” appears in a non-official domain`);
                }
            });

            // phishing phrases used as supporting evidence only 
            // after a URL warning has been found and return back final result
            if (flags.length > 0) {
                const phishingKeywords = [
                    "verify your account",
                    "confirm your identity",
                    "your account has been suspended",
                    "enter your credit card",
                    "urgent action required",
                    "you have won",
                    "click here to claim",
                    "limited time offer"
                ];

                phishingKeywords.forEach((phrase) => {
                    if (pageText.includes(phrase)) {
                        flags.push(`Phishing phrase: “${phrase}”`);
                    }
                });
            }

            // keep message channel VirusTotal/bg is asynchronous
            // so wont close after getting scan result (might use ltr)
            sendResponse({ flags: [...new Set(flags)] });
        });

        return true;
    });
}
