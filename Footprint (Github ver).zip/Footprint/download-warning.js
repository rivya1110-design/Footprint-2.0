document.addEventListener("DOMContentLoaded", () => {
  "use strict";

  const params = new URLSearchParams(window.location.search);
  const downloadId = Number(params.get("downloadId"));

  const riskBadge = document.getElementById("riskBadge");
  const heading = document.getElementById("heading");
  const summary = document.getElementById("summary");
  const filename = document.getElementById("filename");
  const source = document.getElementById("source");
  const reasonList = document.getElementById("reasonList");
  const proceedBtn = document.getElementById("proceedBtn");
  const cancelBtn = document.getElementById("cancelBtn");
  const status = document.getElementById("status");

  proceedBtn.addEventListener("click", () => {
    submitDecision("PROCEED");
  });

  cancelBtn.addEventListener("click", () => {
    submitDecision("CANCEL");
  });

  if (!Number.isFinite(downloadId)) {
    showError("The download ID is invalid.");
    disableButtons();
    return;
  }

  loadPendingDecision();

  function loadPendingDecision() {
    chrome.storage.local.get(
      { pendingDownloadDecisions: {} },
      (data) => {
        if (chrome.runtime.lastError) {
          showError(chrome.runtime.lastError.message);
          disableButtons();
          return;
        }

        const record =
          data.pendingDownloadDecisions?.[String(downloadId)];

        if (!record) {
          showError(
            "This download is no longer waiting for a decision."
          );
          disableButtons();
          return;
        }

        renderRecord(record);
      }
    );
  }

  function renderRecord(record) {
    const risk = String(record.risk || "WARNING").toUpperCase();
    const isDanger = risk === "DANGER";

    riskBadge.textContent = risk;
    riskBadge.className =
      `risk ${isDanger ? "risk-danger" : "risk-warning"}`;

    heading.textContent = isDanger
      ? "Dangerous download detected"
      : "Suspicious download detected";

    summary.textContent = isDanger
      ? "Footprint stopped this download because it contains high-risk indicators. Continue only when you completely trust it."
      : "Footprint paused this download because it needs caution. Review the reasons before continuing.";

    filename.textContent =
      record.filename || "Unknown file";

    source.textContent =
      getHost(record.url);

    reasonList.replaceChildren();

    const reasons = Array.isArray(record.reasons)
      ? record.reasons
      : [];

    if (reasons.length === 0) {
      const item = document.createElement("li");
      item.textContent = "The download requires review.";
      reasonList.appendChild(item);
      return;
    }

    reasons.forEach((reason) => {
      const item = document.createElement("li");
      item.textContent = String(reason);
      reasonList.appendChild(item);
    });
  }

  function submitDecision(action) {
    disableButtons();

    status.className = "status";
    status.textContent =
      action === "PROCEED"
        ? "Trying to resume the download…"
        : "Cancelling the download…";

    chrome.runtime.sendMessage(
      {
        type: "DOWNLOAD_SAFETY_DECISION",
        downloadId,
        action
      },
      (response) => {
        if (chrome.runtime.lastError) {
          showError(chrome.runtime.lastError.message);
          enableButtons();
          return;
        }

        if (!response?.ok) {
          showError(
            response?.message ||
            "The download decision failed."
          );
          enableButtons();
          return;
        }

        status.className = "status success";
        status.textContent = response.message;

        window.setTimeout(() => {
          window.close();
        }, 700);
      }
    );
  }

  function getHost(value) {
    try {
      return new URL(value).hostname || value || "Unknown source";
    } catch (_error) {
      return value || "Unknown source";
    }
  }

  function disableButtons() {
    proceedBtn.disabled = true;
    cancelBtn.disabled = true;
  }

  function enableButtons() {
    proceedBtn.disabled = false;
    cancelBtn.disabled = false;
  }

  function showError(message) {
    status.className = "status error";
    status.textContent = message;
  }
});
