// Footprint background service worker
// Handles website scans, scan-history storage, badges and download monitoring.

// Paste a NEW VirusTotal API key below.
// Do not publish the real key to GitHub.
const VIRUSTOTAL_API_KEY =
    "8bc4693ffae798c52ac1cb2fb2082c95bb4f7b27ea7fe1d27b2ff6715a682a4f";
const RESTRICTED_URL_PATTERN = /^(chrome|edge|about|chrome-extension|view-source):/i;
const MAX_SCAN_HISTORY = 100;
const MAX_DOWNLOAD_HISTORY = 100;
const AUTO_SCAN_DEDUPE_MS = 5000;
const DOWNLOAD_VT_CACHE_TTL_MS = 24 * 60 * 60 * 1000;
const DOWNLOAD_ANALYSIS_POLL_ATTEMPTS = 8;
const DOWNLOAD_ANALYSIS_POLL_DELAY_MS = 2000;
const PENDING_DOWNLOADS_STORAGE_KEY = "pendingDownloadDecisions";
const PENDING_SITES_STORAGE_KEY = "pendingSiteDecisions";
const SITE_APPROVALS_STORAGE_KEY = "siteDecisionApprovals";
const SITE_APPROVAL_TTL_MS = 30 * 60 * 1000;
const SITE_VT_CACHE_TTL_MS = 24 * 60 * 60 * 1000;
const SITE_ANALYSIS_POLL_ATTEMPTS = 8;
const SITE_ANALYSIS_POLL_DELAY_MS = 2000;

function hasConfiguredVirusTotalKey() {
    return Boolean(
        VIRUSTOTAL_API_KEY &&
        !/PASTE|YOUR_|CHANGE_ME|REPLACE_ME/i.test(VIRUSTOTAL_API_KEY)
    );
}


const HIGH_RISK_DOWNLOAD_EXTENSIONS = new Set([
    "exe", "scr", "bat", "cmd", "msi", "vbs", "vbe", "js", "jse",
    "jar", "ps1", "apk", "com", "pif", "gadget", "hta", "lnk",
    "reg", "dll", "cpl", "msp", "application"
]);

const CAUTION_DOWNLOAD_EXTENSIONS = new Set([
    "zip", "rar", "7z", "iso", "img", "dmg", "docm", "xlsm", "pptm"
]);

const SAFE_DANGER_STATES = new Set([
    "safe", "accepted", "deepScannedSafe"
]);

const WARNING_DANGER_STATES = new Set([
    "uncommon", "potentially_unwanted", "unwanted", "asyncScanning",
    "sensitiveContentWarning"
]);

const DANGEROUS_DANGER_STATES = new Set([
    "dangerous", "file", "url", "content", "host", "malicious",
    "dangerous_file", "dangerous_url", "dangerous_content", "dangerous_host",
    "blockedPasswordProtected", "blockedTooLarge", "sensitiveContentBlock"
]);

function classifyVirusTotalSiteStats(stats) {
    const malicious = Number(stats?.malicious || 0);
    const suspicious = Number(stats?.suspicious || 0);
    const harmless = Number(stats?.harmless || 0);
    const undetected = Number(stats?.undetected || 0);

    let verdict = "SAFE";

    if (malicious >= 2) {
        verdict = "DANGER";
    } else if (malicious === 1 || suspicious > 0) {
        verdict = "WARNING";
    }

    return {
        verdict,
        malicious,
        suspicious,
        harmless,
        undetected
    };
}

function wait(milliseconds) {
    return new Promise((resolve) => {
        setTimeout(resolve, milliseconds);
    });
}

async function checkSiteUrlWithVirusTotalDetails(url) {
    if (!hasConfiguredVirusTotalKey()) {
        return {
            status: "API_KEY_MISSING",
            verdict: "UNKNOWN",
            malicious: 0,
            suspicious: 0,
            reason: null
        };
    }

    if (!/^https?:\/\//i.test(String(url || ""))) {
        return {
            status: "URL_UNAVAILABLE",
            verdict: "UNKNOWN",
            malicious: 0,
            suspicious: 0,
            reason: null
        };
    }

    const cacheKey = `vtSiteUrl:${url}`;

    const cached = await new Promise((resolve) => {
        chrome.storage.local.get({ [cacheKey]: null }, (data) => {
            resolve(data[cacheKey]);
        });
    });

    if (
        cached &&
        Number(cached.checkedAt) > 0 &&
        Date.now() - Number(cached.checkedAt) < SITE_VT_CACHE_TTL_MS
    ) {
        return {
            ...cached,
            status: "CACHED"
        };
    }

    try {
        const submission = await fetch(
            "https://www.virustotal.com/api/v3/urls",
            {
                method: "POST",
                headers: {
                    "x-apikey": VIRUSTOTAL_API_KEY,
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: `url=${encodeURIComponent(url)}`
            }
        );

        if (!submission.ok) {
            return {
                status: "API_ERROR",
                verdict: "UNKNOWN",
                malicious: 0,
                suspicious: 0,
                reason: null,
                error: `VirusTotal URL submission failed (${submission.status})`
            };
        }

        const submissionBody = await submission.json();
        const analysisId = submissionBody?.data?.id;

        if (!analysisId) {
            return {
                status: "API_ERROR",
                verdict: "UNKNOWN",
                malicious: 0,
                suspicious: 0,
                reason: null,
                error: "VirusTotal did not return an analysis ID"
            };
        }

        for (
            let attempt = 0;
            attempt < SITE_ANALYSIS_POLL_ATTEMPTS;
            attempt += 1
        ) {
            if (attempt > 0) {
                await wait(SITE_ANALYSIS_POLL_DELAY_MS);
            }

            const response = await fetch(
                `https://www.virustotal.com/api/v3/analyses/${analysisId}`,
                {
                    headers: {
                        "x-apikey": VIRUSTOTAL_API_KEY
                    }
                }
            );

            if (!response.ok) {
                continue;
            }

            const result = await response.json();
            const attributes = result?.data?.attributes || {};

            if (
                attributes.status &&
                attributes.status !== "completed"
            ) {
                continue;
            }

            const classification = classifyVirusTotalSiteStats(
                attributes.stats || {}
            );

            const reason =
                classification.verdict === "SAFE"
                    ? null
                    : `VirusTotal URL result: ${classification.malicious} malicious and ${classification.suspicious} suspicious engine detection(s)`;

            const completed = {
                status: "COMPLETED",
                ...classification,
                reason,
                checkedAt: Date.now()
            };

            chrome.storage.local.set({
                [cacheKey]: completed
            });

            return completed;
        }

        return {
            status: "TIMEOUT",
            verdict: "UNKNOWN",
            malicious: 0,
            suspicious: 0,
            reason: null,
            error: "VirusTotal analysis did not finish in time"
        };
    } catch (error) {
        return {
            status: "NETWORK_ERROR",
            verdict: "UNKNOWN",
            malicious: 0,
            suspicious: 0,
            reason: null,
            error:
                error?.message ||
                "VirusTotal could not be reached"
        };
    }
}

// Compatibility helper for the existing popup CHECK_URL message.
async function checkUrlWithVirusTotal(url) {
    const result = await checkSiteUrlWithVirusTotalDetails(url);

    if (result.verdict === "DANGER" || result.verdict === "WARNING") {
        return "malicious";
    }

    if (result.verdict === "SAFE") {
        return "clean";
    }

    return "error";
}

function computeRisk(flags) {
    if (flags.length >= 3) return "DANGER";
    if (flags.length >= 1) return "WARNING";
    return "SAFE";
}

function setBadge(tabId, risk) {
    const badgeMap = {
        SAFE: { text: "✓", color: "#1e7e34" },
        WARNING: { text: "!", color: "#ff9328" },
        DANGER: { text: "!!", color: "#d62020" }
    };

    const badge = badgeMap[risk] || { text: "", color: "#000000" };
    chrome.action.setBadgeText({ tabId, text: badge.text });
    chrome.action.setBadgeBackgroundColor({ tabId, color: badge.color });
}

function sameFlags(first, second) {
    if (!Array.isArray(first) || !Array.isArray(second)) return false;
    if (first.length !== second.length) return false;
    return first.every((flag, index) => flag === second[index]);
}

function saveScanResult(tabId, url, risk, flags, source = "automatic") {
    const timestamp = Date.now();
    const newScan = {
        id: `scan-${timestamp}-${Math.random().toString(16).slice(2)}`,
        tabId,
        url,
        risk,
        flags: Array.isArray(flags) ? [...flags] : [],
        source,
        timestamp,
        time: new Date(timestamp).toLocaleString()
    };

    chrome.storage.local.get({ scanHistory: [], tabResults: {} }, (data) => {
        const history = Array.isArray(data.scanHistory) ? data.scanHistory : [];
        const last = history[0];
        const lastTimestamp = Number(last?.timestamp) || Date.parse(last?.time || "") || 0;

        // Prevent the automatic page-load event from creating the same record twice,
        // but always preserve manual re-scans as fresh activity.
        const recentAutomaticDuplicate =
            source === "automatic" &&
            last &&
            last.url === url &&
            last.risk === risk &&
            sameFlags(last.flags, newScan.flags) &&
            timestamp - lastTimestamp < AUTO_SCAN_DEDUPE_MS;

        if (recentAutomaticDuplicate) {
            history[0] = {
                ...last,
                ...newScan,
                id: last.id || newScan.id
            };
        } else {
            history.unshift(newScan);
        }

        if (history.length > MAX_SCAN_HISTORY) {
            history.length = MAX_SCAN_HISTORY;
        }

        const tabResults = data.tabResults && typeof data.tabResults === "object"
            ? data.tabResults
            : {};
        tabResults[tabId] = newScan;

        chrome.storage.local.set({ scanHistory: history, tabResults }, () => {
            if (chrome.runtime.lastError) {
                console.error("Could not save scan result:", chrome.runtime.lastError.message);
            }
        });
    });
}

function sendScanMessage(tabId) {
    return new Promise((resolve) => {
        chrome.tabs.sendMessage(tabId, { type: "SCAN_PAGE" }, (response) => {
            if (chrome.runtime.lastError || !response || !Array.isArray(response.flags)) {
                resolve(null);
                return;
            }
            resolve(response.flags);
        });
    });
}

async function requestPageFlags(tabId) {
    // Content scripts from manifest.json are normally already present.
    let flags = await sendScanMessage(tabId);
    if (flags) return flags;

    // Fallback for a tab that was open before the extension was installed/reloaded.
    return new Promise((resolve) => {
        chrome.scripting.executeScript(
            { target: { tabId }, files: ["content.js"] },
            async () => {
                if (chrome.runtime.lastError) {
                    console.warn("Could not inject scanner:", chrome.runtime.lastError.message);
                    resolve(null);
                    return;
                }
                resolve(await sendScanMessage(tabId));
            }
        );
    });
}


function siteDecisionKey(tabId, url) {
    return `${Number(tabId)}::${String(url || "")}`;
}

function readStorageObject(key) {
    return new Promise((resolve) => {
        chrome.storage.local.get({ [key]: {} }, (data) => {
            const value =
                data[key] &&
                typeof data[key] === "object"
                    ? data[key]
                    : {};

            resolve(value);
        });
    });
}

function writeStorageObject(key, value) {
    return new Promise((resolve) => {
        chrome.storage.local.set({ [key]: value }, () => {
            resolve();
        });
    });
}

async function hasActiveSiteApproval(tabId, url) {
    const approvals = await readStorageObject(
        SITE_APPROVALS_STORAGE_KEY
    );

    const key = siteDecisionKey(tabId, url);
    const approval = approvals[key];

    if (!approval) {
        return false;
    }

    if (
        Date.now() - Number(approval.approvedAt || 0) >
        SITE_APPROVAL_TTL_MS
    ) {
        delete approvals[key];
        await writeStorageObject(
            SITE_APPROVALS_STORAGE_KEY,
            approvals
        );
        return false;
    }

    return true;
}

async function saveSiteApproval(tabId, url) {
    const approvals = await readStorageObject(
        SITE_APPROVALS_STORAGE_KEY
    );

    approvals[siteDecisionKey(tabId, url)] = {
        tabId,
        url,
        approvedAt: Date.now()
    };

    await writeStorageObject(
        SITE_APPROVALS_STORAGE_KEY,
        approvals
    );
}

async function savePendingSiteDecision(record) {
    const pending = await readStorageObject(
        PENDING_SITES_STORAGE_KEY
    );

    pending[String(record.tabId)] = record;

    await writeStorageObject(
        PENDING_SITES_STORAGE_KEY,
        pending
    );
}

async function removePendingSiteDecision(tabId) {
    const pending = await readStorageObject(
        PENDING_SITES_STORAGE_KEY
    );

    delete pending[String(tabId)];

    await writeStorageObject(
        PENDING_SITES_STORAGE_KEY,
        pending
    );
}

async function showSiteSafetyPopup(record) {
    const existingPending = await readStorageObject(
        PENDING_SITES_STORAGE_KEY
    );

    const previous = existingPending[String(record.tabId)];

    if (
        previous &&
        previous.url === record.url &&
        Number(previous.popupOpenedAt || 0) > 0 &&
        Date.now() - Number(previous.popupOpenedAt) < 15000
    ) {
        return;
    }

    const storedRecord = {
        ...record,
        popupOpenedAt: Date.now()
    };

    await savePendingSiteDecision(storedRecord);

    const popupUrl = chrome.runtime.getURL(
        `site-warning.html?tabId=${encodeURIComponent(record.tabId)}`
    );

    try {
        await new Promise((resolve, reject) => {
            chrome.windows.create(
                {
                    url: popupUrl,
                    type: "popup",
                    width: 560,
                    height: 610,
                    focused: true
                },
                (windowInfo) => {
                    if (chrome.runtime.lastError) {
                        reject(
                            new Error(
                                chrome.runtime.lastError.message
                            )
                        );
                        return;
                    }

                    resolve(windowInfo);
                }
            );
        });
    } catch (error) {
        console.error(
            "Could not open the website safety popup:",
            error.message
        );

        chrome.notifications.create(
            `site-warning-${record.tabId}`,
            {
                type: "basic",
                iconUrl: "icon/pixel-capybara-pack 1.png",
                title:
                    record.risk === "DANGER"
                        ? "Footprint: Dangerous website"
                        : "Footprint: Suspicious website",
                message:
                    `${record.url} — ${record.reasons[0] || "Review this website before continuing"}`,
                priority: 2,
                requireInteraction: true
            }
        );
    }
}

function goBackOrOpenFootprint(tabId) {
    return new Promise((resolve) => {
        chrome.tabs.goBack(tabId, () => {
            if (!chrome.runtime.lastError) {
                resolve();
                return;
            }

            chrome.tabs.update(
                tabId,
                {
                    url: chrome.runtime.getURL("index.html")
                },
                () => resolve()
            );
        });
    });
}

async function handleSiteSafetyDecision(tabId, action) {
    const pending = await readStorageObject(
        PENDING_SITES_STORAGE_KEY
    );

    const record = pending[String(tabId)];

    if (!record) {
        return {
            ok: false,
            message:
                "This website warning is no longer active."
        };
    }

    const currentTab = await new Promise((resolve) => {
        chrome.tabs.get(tabId, (tab) => {
            if (chrome.runtime.lastError) {
                resolve(null);
                return;
            }

            resolve(tab);
        });
    });

    if (
        currentTab?.url &&
        currentTab.url !== record.url
    ) {
        await removePendingSiteDecision(tabId);

        return {
            ok: false,
            message:
                "The tab has already moved to another page."
        };
    }

    if (action === "CONTINUE") {
        await saveSiteApproval(tabId, record.url);
        await removePendingSiteDecision(tabId);

        return {
            ok: true,
            action,
            message:
                "You chose to continue on the website."
        };
    }

    await removePendingSiteDecision(tabId);
    await goBackOrOpenFootprint(tabId);

    return {
        ok: true,
        action,
        message:
            "Footprint moved you away from the website."
    };
}

async function injectAndScan(tabId, url, source = "automatic") {
    if (
        !tabId ||
        !url ||
        RESTRICTED_URL_PATTERN.test(url) ||
        !/^https?:\/\//i.test(url)
    ) {
        return null;
    }

    const flags = await requestPageFlags(tabId);
    if (!flags) {
        return null;
    }

    const localRisk = computeRisk(flags);
    const virusTotal =
        await checkSiteUrlWithVirusTotalDetails(url);

    const risk = strongerRisk(
        localRisk,
        virusTotal.verdict
    );

    const combinedFlags = mergeUniqueReasons(
        flags,
        virusTotal.reason
            ? [virusTotal.reason]
            : []
    );

    saveScanResult(
        tabId,
        url,
        risk,
        combinedFlags,
        source
    );

    setBadge(tabId, risk);

    const result = {
        url,
        risk,
        flags: combinedFlags,
        virusTotal
    };

    if (
        source === "automatic" &&
        ["WARNING", "DANGER"].includes(risk)
    ) {
        const approved =
            await hasActiveSiteApproval(tabId, url);

        if (!approved) {
            await showSiteSafetyPopup({
                tabId,
                url,
                risk,
                reasons: combinedFlags,
                virusTotal,
                createdAt: Date.now()
            });
        }
    }

    return result;
}

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete" && tab.url && /^https?:\/\//i.test(tab.url)) {
        injectAndScan(tabId, tab.url, "automatic");
    }
});

chrome.tabs.onRemoved.addListener((tabId) => {
    chrome.storage.local.get(
        {
            tabResults: {},
            [PENDING_SITES_STORAGE_KEY]: {},
            [SITE_APPROVALS_STORAGE_KEY]: {}
        },
        (data) => {
            const tabResults = data.tabResults || {};
            delete tabResults[tabId];

            const pending =
                data[PENDING_SITES_STORAGE_KEY] || {};
            delete pending[String(tabId)];

            const approvals =
                data[SITE_APPROVALS_STORAGE_KEY] || {};

            Object.keys(approvals).forEach((key) => {
                if (key.startsWith(`${tabId}::`)) {
                    delete approvals[key];
                }
            });

            chrome.storage.local.set({
                tabResults,
                [PENDING_SITES_STORAGE_KEY]: pending,
                [SITE_APPROVALS_STORAGE_KEY]: approvals
            });
        }
    );
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === "SITE_SAFETY_DECISION") {
        const tabId = Number(message.tabId);
        const action =
            String(message.action || "").toUpperCase();

        if (
            !Number.isFinite(tabId) ||
            !["CONTINUE", "LEAVE"].includes(action)
        ) {
            sendResponse({
                ok: false,
                message: "Invalid website safety decision."
            });
            return false;
        }

        handleSiteSafetyDecision(tabId, action)
            .then((result) => sendResponse(result))
            .catch((error) => {
                sendResponse({
                    ok: false,
                    message:
                        error?.message ||
                        "The website safety decision failed."
                });
            });

        return true;
    }

    if (message.type === "CHECK_URL") {
        checkUrlWithVirusTotal(message.url).then((result) => sendResponse({ result }));
        return true;
    }

    if (message.type === "RESCAN_ACTIVE_TAB") {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const tab = tabs[0];
            if (!tab?.id || !tab.url) {
                sendResponse(null);
                return;
            }

            injectAndScan(tab.id, tab.url, "manual")
                .then((result) => sendResponse(result))
                .catch((error) => {
                    console.error("Manual scan failed:", error);
                    sendResponse(null);
                });
        });
        return true;
    }

    if (message.type === "GET_TAB_RESULT") {
        chrome.storage.local.get({ tabResults: {} }, (data) => {
            const result = data.tabResults?.[message.tabId] || null;
            if (message.url && result?.url !== message.url) {
                sendResponse(null);
                return;
            }
            sendResponse(result);
        });
        return true;
    }
});

function extensionOf(filenameOrUrl) {
    const cleanValue = String(filenameOrUrl || "").split(/[?#]/)[0];
    const match = /\.([a-z0-9]+)$/i.exec(cleanValue);
    return match ? match[1].toLowerCase() : "";
}

function basename(value) {
    const text = String(value || "");
    const finalPart = text.split(/[\\/]/).pop() || "";
    try {
        return decodeURIComponent(finalPart) || "unknown file";
    } catch (_error) {
        return finalPart || "unknown file";
    }
}

function filenameFromDownload(item) {
    if (item?.filename) return basename(item.filename);

    const sourceUrl = item?.finalUrl || item?.url || "";
    try {
        const parsed = new URL(sourceUrl);
        return basename(parsed.pathname);
    } catch (_error) {
        return basename(sourceUrl);
    }
}

function classifyDownload(item) {
    const filename = filenameFromDownload(item);
    const extension = extensionOf(filename) || extensionOf(item?.finalUrl) || extensionOf(item?.url);
    const dangerState = String(item?.danger || "");
    const state = String(item?.state || "in_progress");
    const reasons = [];
    let risk = "SAFE";

    if (DANGEROUS_DANGER_STATES.has(dangerState)) {
        risk = "DANGER";
        reasons.push(`Chrome download protection reported: ${dangerState}`);
    } else if (WARNING_DANGER_STATES.has(dangerState)) {
        risk = "WARNING";
        reasons.push(`Chrome download protection reported: ${dangerState}`);
    }

    if (HIGH_RISK_DOWNLOAD_EXTENSIONS.has(extension)) {
        risk = "DANGER";
        reasons.push(`Potentially dangerous executable or script type (.${extension})`);
    } else if (CAUTION_DOWNLOAD_EXTENSIONS.has(extension) && risk !== "DANGER") {
        risk = "WARNING";
        reasons.push(`Compressed, disk-image or macro-enabled file type (.${extension})`);
    }

    if (state === "interrupted" && risk === "SAFE") {
        risk = "WARNING";
        reasons.push("Download was interrupted before completion");
    }

    if (!dangerState && state === "in_progress" && reasons.length === 0) {
        risk = "CHECKING";
        reasons.push("Download is still being checked");
    }

    if (risk === "SAFE") {
        if (SAFE_DANGER_STATES.has(dangerState)) {
            reasons.push("No warning was reported by Chrome download protection");
        } else {
            reasons.push("No risky file type or browser warning was detected");
        }
    }

    return { risk, reasons, filename, extension, dangerState, state };
}

function riskRank(risk) {
    return { CHECKING: 0, SAFE: 1, WARNING: 2, DANGER: 3 }[risk] || 0;
}

function notifyDownload(record) {
    if (!record || !["WARNING", "DANGER"].includes(record.risk)) return;

    chrome.notifications.create(`download-${record.downloadId}-${record.risk}`, {
        type: "basic",
        iconUrl: "icon/pixel-capybara-pack 1.png",
        title: record.risk === "DANGER"
            ? "⚠️ Footprint: Dangerous download warning"
            : "⚠️ Footprint: Download needs caution",
        message: `${record.filename} — ${record.reasons[0] || "Review this download"}`
    });
}

function upsertDownloadRecord(downloadItem) {
    if (!downloadItem || typeof downloadItem.id !== "number") return;

    const classification = classifyDownload(downloadItem);
    const timestamp = Date.now();

    chrome.storage.local.get({ downloadHistory: [] }, (data) => {
        const history = Array.isArray(data.downloadHistory) ? data.downloadHistory : [];
        const existingIndex = history.findIndex(
            (entry) => Number(entry.downloadId) === Number(downloadItem.id)
        );
        const previous = existingIndex >= 0 ? history[existingIndex] : null;

        const record = {
            id: previous?.id || `download-${downloadItem.id}`,
            downloadId: downloadItem.id,
            filename: classification.filename,
            url: downloadItem.finalUrl || downloadItem.url || previous?.url || "",
            referrer: downloadItem.referrer || previous?.referrer || "",
            mime: downloadItem.mime || previous?.mime || "",
            bytesReceived: Number(downloadItem.bytesReceived || previous?.bytesReceived || 0),
            totalBytes: Number(downloadItem.totalBytes || previous?.totalBytes || 0),
            risk: strongerRisk(
                classification.risk,
                previous?.virusTotalUrl?.verdict
            ),
            reasons: mergeUniqueReasons(
                classification.reasons,
                previous?.virusTotalUrl?.reason
                    ? [previous.virusTotalUrl.reason]
                    : []
            ),
            dangerState: classification.dangerState,
            state: classification.state,
            startedAt: previous?.startedAt || timestamp,
            timestamp,
            time: new Date(timestamp).toLocaleString(),
            notifiedRisk: previous?.notifiedRisk || null,
            virusTotalUrl: previous?.virusTotalUrl || {
                status: "NOT_CHECKED",
                verdict: null,
                malicious: 0,
                suspicious: 0,
                reason: null,
                checkedAt: null
            },
            decisionStatus: previous?.decisionStatus || "ANALYSING",
            pausedByFootprint: Boolean(previous?.pausedByFootprint)
        };

        const shouldNotify =
            ["WARNING", "DANGER"].includes(record.risk) &&
            riskRank(record.risk) > riskRank(previous?.notifiedRisk);

        if (shouldNotify) {
            record.notifiedRisk = record.risk;
        }

        if (existingIndex >= 0) {
            history.splice(existingIndex, 1);
        }
        history.unshift(record);

        if (history.length > MAX_DOWNLOAD_HISTORY) {
            history.length = MAX_DOWNLOAD_HISTORY;
        }

        chrome.storage.local.set({ downloadHistory: history }, () => {
            if (chrome.runtime.lastError) {
                console.error("Could not save download result:", chrome.runtime.lastError.message);
                return;
            }
            if (shouldNotify) notifyDownload(record);
        });
    });
}

function refreshDownloadById(downloadId) {
    chrome.downloads.search({ id: downloadId }, (items) => {
        if (chrome.runtime.lastError) {
            console.warn("Could not read download:", chrome.runtime.lastError.message);
            return;
        }
        if (items?.[0]) upsertDownloadRecord(items[0]);
    });
}

// Automatic download safety gate.
// It pauses a new download when possible, checks local indicators and the
// VirusTotal reputation of the source URL, then resumes safe downloads or
// asks the user to proceed/cancel for warning and danger results.

function mergeUniqueReasons(...reasonLists) {
    const combined = [];

    reasonLists.flat().forEach((reason) => {
        const text = String(reason || "").trim();
        if (text && !combined.includes(text)) {
            combined.push(text);
        }
    });

    return combined;
}

function strongerRisk(firstRisk, secondRisk) {
    const first = String(firstRisk || "CHECKING").toUpperCase();
    const second = String(secondRisk || "CHECKING").toUpperCase();

    return riskRank(second) > riskRank(first) ? second : first;
}

function resolveFinalDownloadRisk(localRisk, virusTotalVerdict) {
    const local = String(localRisk || "CHECKING").toUpperCase();
    const virusTotal = String(
        virusTotalVerdict || "UNKNOWN"
    ).toUpperCase();

    // Local or VirusTotal warning/danger must always be preserved.
    if (local === "DANGER" || virusTotal === "DANGER") {
        return "DANGER";
    }

    if (local === "WARNING" || virusTotal === "WARNING") {
        return "WARNING";
    }

    /*
     * CHECKING is only a temporary state while Chrome assigns the final
     * filename/danger state. If no actual warning exists after the checks,
     * allow the download instead of opening a false warning popup.
     */
    return "SAFE";
}

function callbackToPromise(registerCallback) {
    return new Promise((resolve, reject) => {
        registerCallback(() => {
            if (chrome.runtime.lastError) {
                reject(new Error(chrome.runtime.lastError.message));
                return;
            }

            resolve();
        });
    });
}

function pauseDownload(downloadId) {
    return callbackToPromise((done) => {
        chrome.downloads.pause(downloadId, done);
    });
}

function resumeDownload(downloadId) {
    return callbackToPromise((done) => {
        chrome.downloads.resume(downloadId, done);
    });
}

function cancelDownload(downloadId) {
    return callbackToPromise((done) => {
        chrome.downloads.cancel(downloadId, done);
    });
}

function clearNotification(notificationId) {
    return new Promise((resolve) => {
        chrome.notifications.clear(notificationId, () => resolve());
    });
}

function getDownloadById(downloadId) {
    return new Promise((resolve) => {
        chrome.downloads.search({ id: downloadId }, (items) => {
            if (chrome.runtime.lastError) {
                resolve(null);
                return;
            }

            resolve(items?.[0] || null);
        });
    });
}

function getSourceHost(urlValue) {
    try {
        return new URL(urlValue).hostname || "unknown source";
    } catch (_error) {
        return "unknown source";
    }
}

function updateDownloadHistoryRecord(downloadId, updates) {
    return new Promise((resolve) => {
        chrome.storage.local.get({ downloadHistory: [] }, (data) => {
            if (chrome.runtime.lastError) {
                resolve(null);
                return;
            }

            const history = Array.isArray(data.downloadHistory)
                ? data.downloadHistory
                : [];

            const index = history.findIndex(
                (entry) => Number(entry.downloadId) === Number(downloadId)
            );

            if (index < 0) {
                resolve(null);
                return;
            }

            const current = history[index];
            const timestamp = Date.now();

            const nextRecord = {
                ...current,
                ...updates,
                timestamp,
                time: new Date(timestamp).toLocaleString()
            };

            if (updates.reasons) {
                nextRecord.reasons = mergeUniqueReasons(
                    current.reasons || [],
                    updates.reasons
                );
            }

            history.splice(index, 1);
            history.unshift(nextRecord);

            chrome.storage.local.set({ downloadHistory: history }, () => {
                if (chrome.runtime.lastError) {
                    resolve(null);
                    return;
                }

                resolve(nextRecord);
            });
        });
    });
}

function readPendingDownloadDecisions() {
    return new Promise((resolve) => {
        chrome.storage.local.get(
            { [PENDING_DOWNLOADS_STORAGE_KEY]: {} },
            (data) => {
                const pending =
                    data[PENDING_DOWNLOADS_STORAGE_KEY] &&
                    typeof data[PENDING_DOWNLOADS_STORAGE_KEY] === "object"
                        ? data[PENDING_DOWNLOADS_STORAGE_KEY]
                        : {};

                resolve(pending);
            }
        );
    });
}

function writePendingDownloadDecisions(pending) {
    return new Promise((resolve) => {
        chrome.storage.local.set(
            { [PENDING_DOWNLOADS_STORAGE_KEY]: pending },
            () => resolve()
        );
    });
}

async function savePendingDecision(record) {
    const pending = await readPendingDownloadDecisions();
    pending[String(record.downloadId)] = record;
    await writePendingDownloadDecisions(pending);
}

async function removePendingDecision(downloadId) {
    const pending = await readPendingDownloadDecisions();
    delete pending[String(downloadId)];
    await writePendingDownloadDecisions(pending);
}

function classifyVirusTotalUrlStats(stats) {
    const malicious = Number(stats?.malicious || 0);
    const suspicious = Number(stats?.suspicious || 0);
    const harmless = Number(stats?.harmless || 0);
    const undetected = Number(stats?.undetected || 0);

    let verdict = "SAFE";

    if (malicious >= 2) {
        verdict = "DANGER";
    } else if (malicious === 1 || suspicious > 0) {
        verdict = "WARNING";
    }

    return {
        verdict,
        malicious,
        suspicious,
        harmless,
        undetected
    };
}

function sleep(milliseconds) {
    return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

async function checkDownloadUrlWithVirusTotal(url) {
    /*
     * VirusTotal failures are UNKNOWN, not WARNING.
     * Footprint then falls back to its local extension checks and Chrome's
     * download-protection result instead of falsely warning about safe files.
     */
    function unavailableResult(status, errorMessage = "") {
        return {
            status,
            verdict: "UNKNOWN",
            malicious: 0,
            suspicious: 0,
            harmless: 0,
            undetected: 0,
            reason: null,
            error: errorMessage || null,
            checkedAt: Date.now()
        };
    }

    if (!hasConfiguredVirusTotalKey()) {
        return unavailableResult(
            "API_KEY_MISSING",
            "No valid VirusTotal API key is configured"
        );
    }

    if (!/^https?:\/\//i.test(String(url || ""))) {
        return unavailableResult(
            "URL_UNAVAILABLE",
            "The download source URL is unavailable"
        );
    }

    const cacheKey = `vtDownloadUrl:${url}`;

    const cached = await new Promise((resolve) => {
        chrome.storage.local.get(
            { [cacheKey]: null },
            (data) => {
                resolve(data[cacheKey]);
            }
        );
    });

    if (
        cached &&
        Number(cached.checkedAt) > 0 &&
        Date.now() - Number(cached.checkedAt) <
            DOWNLOAD_VT_CACHE_TTL_MS
    ) {
        return {
            ...cached,
            status: "CACHED"
        };
    }

    try {
        const submission = await fetch(
            "https://www.virustotal.com/api/v3/urls",
            {
                method: "POST",
                headers: {
                    "x-apikey": VIRUSTOTAL_API_KEY,
                    "Content-Type":
                        "application/x-www-form-urlencoded"
                },
                body: `url=${encodeURIComponent(url)}`
            }
        );

        if (!submission.ok) {
            let errorMessage =
                `VirusTotal URL check failed (${submission.status})`;

            try {
                const errorBody = await submission.json();
                errorMessage =
                    errorBody?.error?.message ||
                    errorBody?.message ||
                    errorMessage;
            } catch (_error) {
                // Keep the HTTP error message.
            }

            return unavailableResult(
                "API_ERROR",
                errorMessage
            );
        }

        const submissionBody = await submission.json();
        const analysisId = submissionBody?.data?.id;

        if (!analysisId) {
            return unavailableResult(
                "API_ERROR",
                "VirusTotal did not return an analysis ID"
            );
        }

        for (
            let attempt = 0;
            attempt < DOWNLOAD_ANALYSIS_POLL_ATTEMPTS;
            attempt += 1
        ) {
            if (attempt > 0) {
                await sleep(
                    DOWNLOAD_ANALYSIS_POLL_DELAY_MS
                );
            }

            const response = await fetch(
                `https://www.virustotal.com/api/v3/analyses/${analysisId}`,
                {
                    headers: {
                        "x-apikey": VIRUSTOTAL_API_KEY
                    }
                }
            );

            if (!response.ok) {
                continue;
            }

            const payload = await response.json();
            const attributes =
                payload?.data?.attributes || {};

            if (
                attributes.status &&
                attributes.status !== "completed"
            ) {
                continue;
            }

            const classified =
                classifyVirusTotalUrlStats(
                    attributes.stats || {}
                );

            const reason =
                classified.verdict === "SAFE"
                    ? null
                    : `VirusTotal source URL: ${classified.malicious} malicious and ${classified.suspicious} suspicious engine result(s)`;

            const result = {
                status: "COMPLETED",
                ...classified,
                checkedAt: Date.now(),
                reason,
                error: null
            };

            // Cache only completed VirusTotal results.
            chrome.storage.local.set({
                [cacheKey]: result
            });

            return result;
        }

        return unavailableResult(
            "TIMEOUT",
            "VirusTotal did not finish the source URL analysis in time"
        );
    } catch (error) {
        return unavailableResult(
            "NETWORK_ERROR",
            error?.message ||
                "VirusTotal could not be reached"
        );
    }
}

async function showDownloadDecisionPopup(record) {
    const popupUrl = chrome.runtime.getURL(
        `download-warning.html?downloadId=${encodeURIComponent(record.downloadId)}`
    );

    try {
        const createdWindow = await new Promise((resolve, reject) => {
            chrome.windows.create(
                {
                    url: popupUrl,
                    type: "popup",
                    width: 540,
                    height: 560,
                    focused: true
                },
                (windowInfo) => {
                    if (chrome.runtime.lastError) {
                        reject(
                            new Error(chrome.runtime.lastError.message)
                        );
                        return;
                    }

                    resolve(windowInfo);
                }
            );
        });

        if (createdWindow?.id) {
            return {
                shown: true,
                method: "popup",
                windowId: createdWindow.id
            };
        }
    } catch (error) {
        console.warn(
            "Footprint warning popup could not be opened:",
            error.message
        );
    }

    // Fall back to a Chrome system notification if opening the popup fails.
    return showDownloadDecisionNotification(record);
}

async function showDownloadDecisionNotification(record) {
    const notificationId = `footprint-download-decision-${record.downloadId}`;
    const sourceHost = getSourceHost(record.url);
    const firstReason =
        record.reasons?.[0] ||
        "The download requires review";

    const title =
        record.risk === "DANGER"
            ? "Footprint blocked a dangerous download"
            : "Footprint paused a suspicious download";

    const message =
        `${record.filename} from ${sourceHost}. ${firstReason}. Do you want to proceed?`;

    await new Promise((resolve) => {
        chrome.notifications.create(
            notificationId,
            {
                type: "basic",
                iconUrl: "icon/pixel-capybara-pack 1.png",
                title,
                message,
                priority: 2,
                requireInteraction: true,
                buttons: [
                    { title: "Proceed anyway" },
                    { title: "Cancel download" }
                ]
            },
            () => {
                if (chrome.runtime.lastError) {
                    console.error(
                        "Footprint notification failed:",
                        chrome.runtime.lastError.message
                    );

                    resolve({
                        shown: false,
                        method: "notification",
                        error: chrome.runtime.lastError.message
                    });
                    return;
                }

                resolve({
                    shown: true,
                    method: "notification",
                    notificationId
                });
            }
        );
    });
}

async function beginGuardedDownload(downloadItem) {
    if (!downloadItem || typeof downloadItem.id !== "number") {
        return;
    }

    // Keep the existing history feature working immediately.
    upsertDownloadRecord(downloadItem);

    let paused = false;

    try {
        await pauseDownload(downloadItem.id);
        paused = true;
    } catch (error) {
        // Very small downloads can complete before onCreated is able to pause them.
        console.warn(
            "Footprint could not pause the download:",
            error.message
        );
    }

    // Wait briefly for Chrome to provide the final filename and final URL.
    await sleep(350);
    const latestItem =
        (await getDownloadById(downloadItem.id)) ||
        downloadItem;

    const local = classifyDownload(latestItem);
    const sourceUrl =
        latestItem.finalUrl ||
        latestItem.url ||
        downloadItem.finalUrl ||
        downloadItem.url ||
        "";

    const vt = await checkDownloadUrlWithVirusTotal(sourceUrl);
    const finalRisk = resolveFinalDownloadRisk(
        local.risk,
        vt.verdict
    );
    const reasons = mergeUniqueReasons(
        local.reasons,
        [vt.reason]
    );

    const record = await updateDownloadHistoryRecord(
        latestItem.id,
        {
            filename: local.filename,
            url: sourceUrl,
            risk: finalRisk,
            reasons,
            dangerState: local.dangerState,
            state: latestItem.state || local.state,
            pausedByFootprint: paused,
            virusTotalUrl: {
                status: vt.status,
                verdict: vt.verdict,
                malicious: vt.malicious,
                suspicious: vt.suspicious,
                harmless: vt.harmless || 0,
                undetected: vt.undetected || 0,
                reason: vt.reason,
                error: vt.error || null,
                checkedAt: Date.now()
            },
            decisionStatus:
                finalRisk === "SAFE"
                    ? "AUTO_ALLOWED"
                    : "PENDING_USER_DECISION"
        }
    );

    if (!record) {
        if (paused) {
            try {
                await resumeDownload(latestItem.id);
            } catch (_error) {
                // Nothing else to do.
            }
        }
        return;
    }

    if (finalRisk === "SAFE") {
        if (paused) {
            try {
                await resumeDownload(latestItem.id);
            } catch (error) {
                console.warn(
                    "Footprint could not resume the safe download:",
                    error.message
                );
            }
        }

        await updateDownloadHistoryRecord(
            latestItem.id,
            {
                pausedByFootprint: false,
                decisionStatus: "AUTO_ALLOWED",
                reasons: [
                    "Footprint automatically allowed the download after the safety checks completed"
                ]
            }
        );

        return;
    }

    const pendingRecord = {
        downloadId: latestItem.id,
        filename: record.filename,
        url: sourceUrl,
        risk: finalRisk,
        reasons,
        paused,
        createdAt: Date.now()
    };

    await savePendingDecision(pendingRecord);
    await showDownloadDecisionPopup(pendingRecord);
}

async function handleDownloadDecision(downloadId, action) {
    const pending = await readPendingDownloadDecisions();
    const record = pending[String(downloadId)];

    if (!record) {
        return {
            ok: false,
            message:
                "This download decision is no longer pending."
        };
    }

    const notificationId =
        `footprint-download-decision-${downloadId}`;

    if (action === "PROCEED") {
        if (record.paused) {
            try {
                await resumeDownload(downloadId);
            } catch (error) {
                console.warn(
                    "Could not resume download:",
                    error.message
                );
            }
        }

        await updateDownloadHistoryRecord(
            downloadId,
            {
                pausedByFootprint: false,
                decisionStatus: "USER_PROCEEDED",
                reasons: [
                    "The user chose to proceed after Footprint displayed the warning"
                ]
            }
        );
    } else if (action === "CANCEL") {
        try {
            await cancelDownload(downloadId);
        } catch (error) {
            console.warn(
                "Could not cancel download:",
                error.message
            );
        }

        await updateDownloadHistoryRecord(
            downloadId,
            {
                pausedByFootprint: false,
                state: "cancelled",
                decisionStatus: "USER_CANCELLED",
                reasons: [
                    "The user cancelled the download after Footprint displayed the warning"
                ]
            }
        );
    }

    await removePendingDecision(downloadId);
    await clearNotification(notificationId);

    return {
        ok: true,
        action,
        message:
            action === "PROCEED"
                ? "The download was allowed to continue."
                : "The download was cancelled."
    };
}


chrome.runtime.onMessage.addListener(
    (message, sender, sendResponse) => {
        if (message?.type !== "DOWNLOAD_SAFETY_DECISION") {
            return false;
        }

        const downloadId = Number(message.downloadId);
        const action = String(message.action || "").toUpperCase();

        if (
            !Number.isFinite(downloadId) ||
            !["PROCEED", "CANCEL"].includes(action)
        ) {
            sendResponse({
                ok: false,
                message: "Invalid download decision."
            });
            return false;
        }

        handleDownloadDecision(downloadId, action)
            .then((result) => sendResponse(result))
            .catch((error) => {
                sendResponse({
                    ok: false,
                    message:
                        error?.message ||
                        "The download decision failed."
                });
            });

        return true;
    }
);

chrome.notifications.onButtonClicked.addListener(
    (notificationId, buttonIndex) => {
        const prefix = "footprint-download-decision-";

        if (!notificationId.startsWith(prefix)) {
            return;
        }

        const downloadId = Number(
            notificationId.slice(prefix.length)
        );

        if (!Number.isFinite(downloadId)) {
            return;
        }

        handleDownloadDecision(
            downloadId,
            buttonIndex === 0 ? "PROCEED" : "CANCEL"
        );
    }
);

chrome.notifications.onClosed.addListener(
    async (notificationId, byUser) => {
        const prefix = "footprint-download-decision-";

        if (
            !byUser ||
            !notificationId.startsWith(prefix)
        ) {
            return;
        }

        const downloadId = Number(
            notificationId.slice(prefix.length)
        );

        if (!Number.isFinite(downloadId)) {
            return;
        }

        // Dismissing the warning does not approve the download.
        // Keep it paused and record that the user has not decided.
        await updateDownloadHistoryRecord(
            downloadId,
            {
                decisionStatus: "WARNING_DISMISSED_DOWNLOAD_PAUSED",
                reasons: [
                    "The warning was dismissed, so the download remains paused"
                ]
            }
        );
    }
);

// Record and analyse every new download.
chrome.downloads.onCreated.addListener((downloadItem) => {
    beginGuardedDownload(downloadItem).catch((error) => {
        console.error(
            "Automatic download safety gate failed:",
            error
        );

        // Preserve the original feature even if the gate fails.
        upsertDownloadRecord(downloadItem);
    });
});

// Continue updating filename, Chrome danger status and completion state.
chrome.downloads.onChanged.addListener((delta) => {
    if (
        delta.filename ||
        delta.danger ||
        delta.state ||
        delta.bytesReceived ||
        delta.totalBytes ||
        delta.finalUrl
    ) {
        refreshDownloadById(delta.id);
    }
});

